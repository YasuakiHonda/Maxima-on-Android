installdir=/data/data/jp.yhonda/files; export installdir
qe=$installdir/additions/qepcad ; export qe
if [ -e $installdir/x86 ]; then
  binname=$qe/bin/qepcad.x86
else
  binname=$qe/bin/qepcad
fi
$binname < $installdir/qepcad_input.txt > $installdir/qepcad_output.txt

