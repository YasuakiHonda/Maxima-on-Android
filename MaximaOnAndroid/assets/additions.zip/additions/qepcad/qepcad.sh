#! /system/bin/sh
installdir=/data/data/jp.yhonda/files; export installdir
qe=$installdir/additions/qepcad ; export qe
$qe/qepcad < $installdir/qepcad_input.txt > $installdir/qepcad_output.txt
